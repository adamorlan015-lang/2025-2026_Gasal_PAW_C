<!DOCTYPE html>
<html>
<body>

<?php
$color = "red";
echo "My car is " . $color . "<br>";
echo "My house is " . $COLOR . "<br>";  // beda huruf, tidak terbaca
echo "My boat is " . $coLOR . "<br>";   // beda huruf, tidak terbaca
?>

</body>
</html>
