<?php
echo strlen("Hello world!"); // outputs 12
?>
