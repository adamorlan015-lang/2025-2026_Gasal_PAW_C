<?php
// Deklarasi variabel
$txt = "Hello world!";
$x = 5;
$y = 10.5;

// Menampilkan output variabel
$txt = "W3Schools.com";
echo "I love $txt!";
?>
