<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Form Input Surname</title>
</head>
<body>
    <h2>Form Input Surname</h2>

    <form method="post" action="soal1.php">
        <label>Masukkan Surname:</label><br>
        <input type="text" name="surname" required>
        <br><br>
        <input type="submit" value="Kirim">
    </form>
</body>
</html>
