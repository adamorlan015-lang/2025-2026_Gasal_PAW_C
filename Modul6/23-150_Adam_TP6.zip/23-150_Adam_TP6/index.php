<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Anggota Keluarga</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrapper">
        <header>
            <h1>🧑‍👩‍👧‍👦 Daftar Anggota Keluarga</h1>
            <p>Analisis nama berdasarkan jumlah kata, huruf, vokal, konsonan, dan bentuk terbalik.</p>
        </header>

        <main>
            <?php
            $anggota_keluarga = ["Andi Pratama", "Siti Aminah", "Budi Santoso", "Rina Kartika"];

            foreach ($anggota_keluarga as $nama) {
                $jumlah_kata = str_word_count($nama);
                $jumlah_huruf = strlen(str_replace(' ', '', $nama));
                $nama_terbalik = strrev($nama);
                $vokal = preg_match_all('/[aeiouAEIOU]/', $nama);
                $konsonan = preg_match_all('/[bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ]/', $nama);
                echo "
                <div class='card'>
                    <h2>$nama</h2>
                    <ul>
                        <li><strong>Jumlah Kata:</strong> $jumlah_kata</li>
                        <li><strong>Jumlah Huruf:</strong> $jumlah_huruf</li>
                        <li><strong>Nama Terbalik:</strong> $nama_terbalik</li>
                        <li><strong>Jumlah Vokal:</strong> $vokal</li>
                        <li><strong>Jumlah Konsonan:</strong> $konsonan</li>
                    </ul>
                </div>
                ";
            }
            ?>
        </main>

        <footer>
            <p>&copy; 2025 Aplikasi Nama Keluarga. Dibuat dengan ❤️ oleh Anda.</p>
        </footer>
    </div>
</body>
</html>
