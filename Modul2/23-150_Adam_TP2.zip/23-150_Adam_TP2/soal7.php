<?php 
for ($x = 0; $x <= 10; $x++) {     echo "The number is: $x <br>"; 
} 
?> 
