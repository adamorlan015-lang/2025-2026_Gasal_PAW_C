<?php
$t = date("h");

if ($t < "20") {
    echo "have a good day!";
}
?>