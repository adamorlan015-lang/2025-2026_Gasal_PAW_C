<?php  
// Inisialisasi array buah
$fruits = array("Avocado", "Blueberry", "Cherry");  
$arrlength = count($fruits);  

// 3.2.1 - Menambahkan buah baru ke dalam array
$newFruits = array("Banana", "Apple", "Watermelon", "Mango", "Papaya");  

for ($x = 0; $x < count($newFruits); $x++) {  
    $fruits[] = $newFruits[$x]; // Menambahkan data baru ke dalam array  
}

// Menampilkan semua elemen dalam array $fruits
$arrlength = count($fruits);  
for ($x = 0; $x < $arrlength; $x++) {  
    echo $fruits[$x] . "<br>";  
}

echo "Panjang array \$fruits saat ini: $arrlength<br><br>";  

// 3.2.2 - Menampilkan data dari array sayuran
$veggies = array("Carrot", "Broccoli", "Spinach");  
$veggiesLength = count($veggies);  

for ($y = 0; $y < $veggiesLength; $y++) {  
    echo $veggies[$y] . "<br>";  
}  
?>  
