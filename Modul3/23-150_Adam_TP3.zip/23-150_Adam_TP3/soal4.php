<?php  
// Inisialisasi array asosiatif tinggi badan
$height = array(
    "Andy" => "176",
    "Barry" => "165",
    "Charlie" => "170"
);

// 3.4.1 - Menambahkan data tinggi baru
$height["David"] = "180";
$height["Eva"] = "162";
$height["Frank"] = "175";
$height["Grace"] = "168";
$height["Hannah"] = "158";

// Menampilkan semua data tinggi menggunakan foreach
foreach ($height as $x => $x_value) {
    echo "Key = " . $x . ", Value = " . $x_value . "<br>";
}

// 3.4.2 - Inisialisasi array asosiatif berat badan
$weight = array(
    "Andy" => "70",
    "Barry" => "65",
    "Charlie" => "75"
);

// Menampilkan semua data berat menggunakan perulangan for
$weightLength = count($weight);

for ($i = 0; $i < $weightLength; $i++) {
    $key = array_keys($weight)[$i];
    echo "Key = " . $key . ", Value = " . $weight[$key] . "<br>";
}
?>  
