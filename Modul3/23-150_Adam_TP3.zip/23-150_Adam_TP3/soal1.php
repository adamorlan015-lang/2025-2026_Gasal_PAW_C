<?php  
// 3.1.1
$fruits = array("Avocado", "Blueberry", "Cherry");

// Menambahkan beberapa buah ke dalam array
array_push($fruits, "Banana", "Apple", "Watermelon", "Mango", "Papaya");

// Menampilkan semua buah
echo "I like " . $fruits[0] . ", " . $fruits[1] . ", " . $fruits[2] . ", " . 
     $fruits[3] . ", " . $fruits[4] . ", " . $fruits[5] . ", " . 
     $fruits[6] . " and " . $fruits[7] . ".<br>";

// Menampilkan nilai dan indeks tertinggi
$nilaiTertinggi = count($fruits) - 1;
echo "Nilai dengan indeks tertinggi: " . $fruits[$nilaiTertinggi] . "<br>";
echo "Indeks tertinggi: $nilaiTertinggi<br>";

// 3.1.2 - Menghapus elemen "Cherry"
$keyToRemove = array_search("Cherry", $fruits);
if ($keyToRemove !== false) {
    unset($fruits[$keyToRemove]);
}

echo "<br>Setelah menghapus 'Cherry':<br>";
$nilaiTertinggi = count($fruits) - 1;
echo "Nilai dengan indeks tertinggi: " . $fruits[$nilaiTertinggi] . "<br>";
echo "Indeks tertinggi: $nilaiTertinggi<br>";

// 3.1.3 - Menampilkan sayuran
$veggies = array("Carrot", "Broccoli", "Spinach");

echo "<br>Vegetables:<br>";
foreach ($veggies as $veggie) {
    echo $veggie . "<br>";
}
?>  
