<?php  
// Inisialisasi array asosiatif berisi tinggi badan
$height = array(
    "Andy" => "176",
    "Barry" => "165",
    "Charlie" => "170"
);

// Menampilkan tinggi Andy
echo "Andy is " . $height['Andy'] . " cm tall.<br>";

// 3.3.1 - Menambahkan data tinggi baru
$height["David"] = "180";
$height["Eva"] = "162";
$height["Frank"] = "175";
$height["Grace"] = "168";
$height["Hannah"] = "158";

// Mendapatkan indeks (key) terakhir
$arrlength = count($height);
$lastIndex = array_keys($height)[$arrlength - 1];

echo "The height of " . $lastIndex . " is " . $height[$lastIndex] . " cm.<br>";

// 3.3.2 - Menghapus data "Charlie"
unset($height["Charlie"]);

// Menampilkan data terakhir setelah penghapusan
$arrlength = count($height);
$lastIndex = array_keys($height)[$arrlength - 1];

echo "After deletion, the height of " . $lastIndex . " is " . $height[$lastIndex] . " cm.<br>";

// 3.3.3 - Inisialisasi array berat badan
$weight = array(
    "Andy" => "70",
    "Barry" => "65",
    "Charlie" => "75"
);

// Menampilkan data berat pada indeks kedua
$secondWeight = array_keys($weight)[1];
echo "The weight of " . $secondWeight . " is " . $weight[$secondWeight] . " kg.";
?>  
